"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface DayResult {
  time: string
  numbers: string
}

interface NumberFrequency {
  number: number
  count: number
  percentage: number
}

interface StatisticsPanelProps {
  results: DayResult[]
  selectedDate: string
}

export function StatisticsPanel({ results, selectedDate }: StatisticsPanelProps) {
  const [numberFrequency, setNumberFrequency] = useState<NumberFrequency[]>([])
  const [hotNumbers, setHotNumbers] = useState<NumberFrequency[]>([])
  const [coldNumbers, setColdNumbers] = useState<NumberFrequency[]>([])
  const [showStats, setShowStats] = useState(false)

  const analyzeNumbers = () => {
    const frequencyMap = new Map<number, number>()
    let totalNumbers = 0

    // Count frequency of each number
    results.forEach((result) => {
      const numbers = result.numbers.split(", ").map((num) => Number.parseInt(num))
      numbers.forEach((num) => {
        frequencyMap.set(num, (frequencyMap.get(num) || 0) + 1)
        totalNumbers++
      })
    })

    // Convert to array and calculate percentages
    const frequencies: NumberFrequency[] = Array.from(frequencyMap.entries())
      .map(([number, count]) => ({
        number,
        count,
        percentage: (count / totalNumbers) * 100,
      }))
      .sort((a, b) => b.count - a.count)

    setNumberFrequency(frequencies)
    setHotNumbers(frequencies.slice(0, 10)) // Top 10 most frequent
    setColdNumbers(frequencies.slice(-10).reverse()) // Bottom 10 least frequent
  }

  const getNumberRangeDistribution = () => {
    const ranges = {
      "6000-6199": 0,
      "6200-6399": 0,
      "6400-6599": 0,
      "6600-6799": 0,
      "6800-6999": 0,
    }

    numberFrequency.forEach(({ number, count }) => {
      if (number >= 6000 && number <= 6199) ranges["6000-6199"] += count
      else if (number >= 6200 && number <= 6399) ranges["6200-6399"] += count
      else if (number >= 6400 && number <= 6599) ranges["6400-6599"] += count
      else if (number >= 6600 && number <= 6799) ranges["6600-6799"] += count
      else if (number >= 6800 && number <= 6999) ranges["6800-6999"] += count
    })

    return ranges
  }

  const getPatternAnalysis = () => {
    let evenCount = 0
    let oddCount = 0
    let ascendingPatterns = 0
    let descendingPatterns = 0

    results.forEach((result) => {
      const numbers = result.numbers.split(", ").map((num) => Number.parseInt(num))

      // Count even/odd
      numbers.forEach((num) => {
        if (num % 2 === 0) evenCount++
        else oddCount++
      })

      // Check for ascending/descending patterns
      const sortedAsc = [...numbers].sort((a, b) => a - b)
      const sortedDesc = [...numbers].sort((a, b) => b - a)

      if (JSON.stringify(numbers) === JSON.stringify(sortedAsc)) ascendingPatterns++
      if (JSON.stringify(numbers) === JSON.stringify(sortedDesc)) descendingPatterns++
    })

    return {
      evenCount,
      oddCount,
      evenPercentage: (evenCount / (evenCount + oddCount)) * 100,
      oddPercentage: (oddCount / (evenCount + oddCount)) * 100,
      ascendingPatterns,
      descendingPatterns,
    }
  }

  useEffect(() => {
    if (results.length > 0) {
      analyzeNumbers()
    }
  }, [results])

  const rangeDistribution = getNumberRangeDistribution()
  const patternAnalysis = getPatternAnalysis()

  if (!showStats) {
    return (
      <div className="mt-8 text-center">
        <Button
          onClick={() => setShowStats(true)}
          className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded"
        >
          Show Statistics & Patterns
        </Button>
      </div>
    )
  }

  return (
    <div className="mt-8 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-center">Statistics & Patterns for {selectedDate}</h2>
        <Button
          onClick={() => setShowStats(false)}
          className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded"
        >
          Hide Stats
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Hot Numbers */}
        <Card className="bg-blue-800/30 border-blue-600">
          <CardHeader>
            <CardTitle className="text-red-400 text-center">🔥 Hot Numbers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {hotNumbers.slice(0, 5).map((item, index) => (
                <div key={item.number} className="flex justify-between items-center">
                  <span className="font-mono text-lg">{item.number}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{item.count}x</span>
                    <div className="w-16 bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-red-500 h-2 rounded-full"
                        style={{ width: `${Math.min(item.percentage * 4, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Cold Numbers */}
        <Card className="bg-blue-800/30 border-blue-600">
          <CardHeader>
            <CardTitle className="text-blue-400 text-center">❄️ Cold Numbers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {coldNumbers.slice(0, 5).map((item, index) => (
                <div key={item.number} className="flex justify-between items-center">
                  <span className="font-mono text-lg">{item.number}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{item.count}x</span>
                    <div className="w-16 bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full"
                        style={{ width: `${Math.min(item.percentage * 4, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Even/Odd Distribution */}
        <Card className="bg-blue-800/30 border-blue-600">
          <CardHeader>
            <CardTitle className="text-yellow-400 text-center">⚖️ Even/Odd Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Even Numbers:</span>
                <span className="font-bold">{patternAnalysis.evenPercentage.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div
                  className="bg-green-500 h-3 rounded-full"
                  style={{ width: `${patternAnalysis.evenPercentage}%` }}
                />
              </div>
              <div className="flex justify-between items-center">
                <span>Odd Numbers:</span>
                <span className="font-bold">{patternAnalysis.oddPercentage.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div
                  className="bg-purple-500 h-3 rounded-full"
                  style={{ width: `${patternAnalysis.oddPercentage}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Number Range Distribution */}
        <Card className="bg-blue-800/30 border-blue-600">
          <CardHeader>
            <CardTitle className="text-green-400 text-center">📊 Range Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(rangeDistribution).map(([range, count]) => {
                const maxCount = Math.max(...Object.values(rangeDistribution))
                const percentage = maxCount > 0 ? (count / maxCount) * 100 : 0
                return (
                  <div key={range} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>{range}</span>
                      <span>{count}</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: `${percentage}%` }} />
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Pattern Analysis */}
        <Card className="bg-blue-800/30 border-blue-600">
          <CardHeader>
            <CardTitle className="text-orange-400 text-center">🔍 Pattern Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Total Draws:</span>
                <span className="font-bold">{results.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Ascending Patterns:</span>
                <span className="font-bold">{patternAnalysis.ascendingPatterns}</span>
              </div>
              <div className="flex justify-between">
                <span>Descending Patterns:</span>
                <span className="font-bold">{patternAnalysis.descendingPatterns}</span>
              </div>
              <div className="flex justify-between">
                <span>Random Patterns:</span>
                <span className="font-bold">
                  {results.length - patternAnalysis.ascendingPatterns - patternAnalysis.descendingPatterns}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats */}
        <Card className="bg-blue-800/30 border-blue-600">
          <CardHeader>
            <CardTitle className="text-cyan-400 text-center">📈 Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Unique Numbers:</span>
                <span className="font-bold">{numberFrequency.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Most Frequent:</span>
                <span className="font-bold font-mono">{hotNumbers[0]?.number || "N/A"}</span>
              </div>
              <div className="flex justify-between">
                <span>Least Frequent:</span>
                <span className="font-bold font-mono">{coldNumbers[0]?.number || "N/A"}</span>
              </div>
              <div className="flex justify-between">
                <span>Avg per Draw:</span>
                <span className="font-bold">10 numbers</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Frequency Table */}
      <Card className="bg-blue-800/30 border-blue-600">
        <CardHeader>
          <CardTitle className="text-white text-center">Complete Number Frequency</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2 max-h-64 overflow-y-auto">
            {numberFrequency.map((item) => (
              <div
                key={item.number}
                className="flex justify-between items-center p-2 bg-blue-900/50 rounded border border-blue-600"
              >
                <span className="font-mono text-sm">{item.number}</span>
                <span className="text-xs text-blue-300">{item.count}x</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
