"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { StatisticsPanel } from "./statistics-panel"
import { usePersistentResults } from "@/hooks/use-persistent-results"

interface ResultsPageProps {
  onClose: () => void
}

interface DayResult {
  time: string
  numbers: string
  id: string
  date: string
}

export function ResultsPage({ onClose }: ResultsPageProps) {
  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date()
    return today.toISOString().split("T")[0]
  })
  const [dayResults, setDayResults] = useState<DayResult[]>([])
  const [isNewResult, setIsNewResult] = useState<string | null>(null)
  const [lastResultCount, setLastResultCount] = useState(0)

  // Use the persistent results hook for real-time data
  const { results, isLoaded } = usePersistentResults()

  // Filter results by selected date
  const filterResultsByDate = (date: string) => {
    const filteredResults = results.filter((result) => result.date === date)
    return filteredResults.map((result) => ({
      time: result.time,
      numbers: result.numbers,
      id: result.id,
      date: result.date,
    }))
  }

  const handleSearch = () => {
    const realResults = filterResultsByDate(selectedDate)
    setDayResults(realResults)
  }

  const formatDisplayDate = (dateStr: string) => {
    return dateStr.replace(/-/g, "/")
  }

  // Real-time updates effect
  useEffect(() => {
    if (isLoaded && results.length > lastResultCount) {
      // New result detected
      const latestResult = results[0]
      if (latestResult && latestResult.date === selectedDate) {
        // Update results if the new result is for the currently selected date
        handleSearch()

        // Show animation for new result
        setIsNewResult(latestResult.id)
        setTimeout(() => setIsNewResult(null), 3000)
      }
      setLastResultCount(results.length)
    }
  }, [results, isLoaded, selectedDate, lastResultCount])

  // Initial load and when date changes
  useEffect(() => {
    if (isLoaded) {
      handleSearch()
      setLastResultCount(results.length)
    }
  }, [selectedDate, isLoaded])

  // Listen for manual draw events
  useEffect(() => {
    const handleManualDraw = () => {
      // Refresh results when manual draw occurs
      setTimeout(() => {
        handleSearch()
      }, 100)
    }

    window.addEventListener("manual_draw_trigger", handleManualDraw)
    return () => window.removeEventListener("manual_draw_trigger", handleManualDraw)
  }, [selectedDate])

  // Auto-refresh every 30 seconds to catch any missed updates
  useEffect(() => {
    const interval = setInterval(() => {
      if (isLoaded) {
        handleSearch()
      }
    }, 30000) // 30 seconds

    return () => clearInterval(interval)
  }, [selectedDate, isLoaded])

  return (
    <div className="fixed inset-0 bg-gradient-to-b from-blue-900 to-blue-950 text-white z-50 overflow-auto">
      <div className="max-w-6xl mx-auto p-4">
        {/* Header with Home button and Date Selection */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <Button onClick={onClose} className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded">
            Home
          </Button>

          <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
            <label className="text-white font-semibold">Select Date *</label>
            <div className="flex gap-2">
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-white text-black px-3 py-2 rounded"
              />
              <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded">
                Search
              </Button>
            </div>
          </div>
        </div>

        {/* Live Update Indicator */}
        <div className="text-center mb-4">
          <div className="inline-flex items-center gap-2 bg-green-600/20 px-4 py-2 rounded-full border border-green-600">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm text-green-300">Live Updates Active - Results update automatically</span>
          </div>
        </div>

        {/* Results Header */}
        <div className="text-center mb-8">
          <h1 className="text-xl">
            <span className="text-red-500">Result of Date : </span>
            <span className="text-red-400">{formatDisplayDate(selectedDate)}</span>
          </h1>
          <div className="text-sm text-blue-300 mt-2">
            Showing {dayResults.length} results • Last updated: {new Date().toLocaleTimeString()}
          </div>
        </div>

        {/* Results Table */}
        <div className="border border-blue-400 rounded-lg overflow-hidden">
          <div className="grid grid-cols-2 bg-blue-800/50">
            <div className="p-4 text-center font-semibold border-r border-blue-400">Draw Time</div>
            <div className="p-4 text-center font-semibold">Winning Numbers</div>
          </div>

          {dayResults.map((result, index) => (
            <div
              key={result.id}
              className={`grid grid-cols-2 border-t border-blue-400 hover:bg-blue-800/30 transition-all duration-500 ${
                isNewResult === result.id ? "bg-green-600/30 animate-pulse border-green-400" : ""
              }`}
            >
              <div className="p-4 text-center border-r border-blue-400 font-semibold">
                {isNewResult === result.id && <span className="inline-block mr-2 text-green-400">🆕</span>}
                {result.time}
              </div>
              <div className="p-4 text-center font-mono text-sm md:text-base">{result.numbers}</div>
            </div>
          ))}

          {dayResults.length === 0 && (
            <div className="p-8 text-center">
              <div className="text-lg text-blue-300">No lottery results found for this date</div>
              <div className="text-sm text-blue-400 mt-2">
                Results are only available for dates when draws have been conducted.
                <br />
                Use the Admin Panel to add results or enable auto-draw for future results.
              </div>
            </div>
          )}
        </div>

        {/* Real-time Status */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center gap-4 text-sm text-blue-300">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
              <span>Auto-refresh every 30s</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>Real-time updates enabled</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
              <span>Total results: {dayResults.length}</span>
            </div>
          </div>
        </div>

        {/* Statistics Panel */}
        <StatisticsPanel results={dayResults} selectedDate={selectedDate} />

        {/* Footer Info */}
        <div className="mt-8 text-center text-blue-300">
          <p>Showing all lottery results for {formatDisplayDate(selectedDate)}</p>
          <p className="text-sm mt-2">
            {selectedDate === new Date().toISOString().split("T")[0]
              ? "Today's results update automatically as new draws occur"
              : "Historical results from selected date"}
          </p>
        </div>
      </div>
    </div>
  )
}
