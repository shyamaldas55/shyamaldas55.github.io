"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { usePersistentResults } from "@/hooks/use-persistent-results"

interface AdminPanelProps {
  onClose: () => void
}

interface LotteryResult {
  id: string
  time: string
  numbers: string
  date: string
}

interface AdminSettings {
  drawInterval: number
  maxNumber: number
  minNumber: number
  numbersPerDraw: number
  autoGenerate: boolean
}

export function AdminPanel({ onClose }: AdminPanelProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [activeTab, setActiveTab] = useState("control")
  const [newResult, setNewResult] = useState({
    time: "",
    numbers: "",
    date: new Date().toISOString().split("T")[0],
  })
  const [editingResult, setEditingResult] = useState<LotteryResult | null>(null)

  // Load settings from localStorage
  const loadSettings = () => {
    try {
      const saved = localStorage.getItem("lottery_settings")
      return saved
        ? JSON.parse(saved)
        : {
            drawInterval: 10,
            maxNumber: 9999,
            minNumber: 1000,
            numbersPerDraw: 5,
            autoGenerate: true,
          }
    } catch {
      return {
        drawInterval: 10,
        maxNumber: 9999,
        minNumber: 1000,
        numbersPerDraw: 5,
        autoGenerate: true,
      }
    }
  }

  const [settings, setSettings] = useState<AdminSettings>(loadSettings())
  const [bulkResults, setBulkResults] = useState("")

  // Auto draw control state
  const [autoDrawEnabled, setAutoDrawEnabled] = useState(() => {
    try {
      return localStorage.getItem("auto_draw_enabled") === "true"
    } catch {
      return false
    }
  })

  const { results, isLoaded, addResult, updateResult, deleteResult, clearAllResults, addMultipleResults } =
    usePersistentResults()

  // Save settings to localStorage
  const saveSettings = () => {
    try {
      localStorage.setItem("lottery_settings", JSON.stringify(settings))
      // Trigger storage event for other tabs/windows
      window.dispatchEvent(
        new StorageEvent("storage", {
          key: "lottery_settings",
          newValue: JSON.stringify(settings),
        }),
      )
      alert("Settings saved successfully!")
    } catch (error) {
      console.error("Error saving settings:", error)
      alert("Error saving settings!")
    }
  }

  // Mock authentication
  const handleLogin = () => {
    if (username === "admin" && password === "admin123") {
      setIsAuthenticated(true)
      loadResults()
    } else {
      alert("Invalid credentials! Use admin/admin123")
    }
  }

  // Load existing results
  const loadResults = () => {
    // Results are now automatically loaded from localStorage via the hook
  }

  // Toggle auto draw
  const toggleAutoDraw = () => {
    const newStatus = !autoDrawEnabled
    setAutoDrawEnabled(newStatus)
    try {
      localStorage.setItem("auto_draw_enabled", newStatus.toString())
      // Trigger storage event for other tabs/windows
      window.dispatchEvent(
        new StorageEvent("storage", {
          key: "auto_draw_enabled",
          newValue: newStatus.toString(),
        }),
      )
    } catch (error) {
      console.error("Error saving auto draw status:", error)
    }
  }

  // Generate random numbers
  const generateRandomNumbers = () => {
    const numbers = []
    for (let i = 0; i < settings.numbersPerDraw; i++) {
      numbers.push(Math.floor(Math.random() * (settings.maxNumber - settings.minNumber + 1)) + settings.minNumber)
    }
    return numbers.join(", ")
  }

  // Manual draw trigger
  const handleManualDraw = () => {
    const now = new Date()
    const timeString = now.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    })

    addResult({
      time: timeString,
      numbers: generateRandomNumbers(),
      date: now.toISOString().split("T")[0],
    })

    // Trigger manual draw event for main page
    window.dispatchEvent(new CustomEvent("manual_draw_trigger"))
    alert("Manual draw completed successfully!")
  }

  // Add new result
  const handleAddResult = () => {
    if (!newResult.time || !newResult.numbers || !newResult.date) {
      alert("Please fill all fields")
      return
    }

    addResult({
      time: newResult.time,
      numbers: newResult.numbers,
      date: newResult.date,
    })

    setNewResult({ time: "", numbers: "", date: new Date().toISOString().split("T")[0] })
    alert("Result added successfully!")
  }

  // Update existing result
  const handleUpdateResult = () => {
    if (!editingResult) return

    updateResult(editingResult)
    setEditingResult(null)
    alert("Result updated successfully!")
  }

  // Delete result
  const handleDeleteResult = (id: string) => {
    if (confirm("Are you sure you want to delete this result?")) {
      deleteResult(id)
      alert("Result deleted successfully!")
    }
  }

  // Bulk import results
  const handleBulkImport = () => {
    try {
      const lines = bulkResults.trim().split("\n")
      const newResults: Omit<LotteryResult, "id">[] = []

      lines.forEach((line) => {
        const [time, numbers] = line.split("|")
        if (time && numbers) {
          newResults.push({
            time: time.trim(),
            numbers: numbers.trim(),
            date: new Date().toISOString().split("T")[0],
          })
        }
      })

      addMultipleResults(newResults)
      setBulkResults("")
      alert(`${newResults.length} results imported successfully!`)
    } catch (error) {
      alert("Error importing results. Please check the format.")
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 bg-gradient-to-b from-blue-900 to-blue-950 text-white z-50 flex items-center justify-center">
        <Card className="w-96 bg-blue-800/50 border-blue-600">
          <CardHeader>
            <CardTitle className="text-center text-2xl">🔐 Admin Login</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-white text-black"
                placeholder="Enter username"
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-white text-black"
                placeholder="Enter password"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleLogin} className="flex-1 bg-green-600 hover:bg-green-700">
                Login
              </Button>
              <Button onClick={onClose} className="flex-1 bg-gray-600 hover:bg-gray-700">
                Cancel
              </Button>
            </div>
            <div className="text-sm text-center text-blue-300">Demo credentials: admin / admin123</div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-gradient-to-b from-blue-900 to-blue-950 text-white z-50 overflow-auto">
      <div className="max-w-7xl mx-auto p-4">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">🎯 Admin Control Panel</h1>
          <div className="flex gap-2">
            <Button onClick={() => setIsAuthenticated(false)} className="bg-yellow-600 hover:bg-yellow-700">
              Logout
            </Button>
            <Button onClick={onClose} className="bg-gray-600 hover:bg-gray-700">
              Close
            </Button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-2 mb-6">
          <Button
            onClick={() => setActiveTab("control")}
            className={`${activeTab === "control" ? "bg-blue-600" : "bg-blue-800"} hover:bg-blue-700`}
          >
            Draw Control
          </Button>
          <Button
            onClick={() => setActiveTab("results")}
            className={`${activeTab === "results" ? "bg-blue-600" : "bg-blue-800"} hover:bg-blue-700`}
          >
            Manage Results
          </Button>
          <Button
            onClick={() => setActiveTab("settings")}
            className={`${activeTab === "settings" ? "bg-blue-600" : "bg-blue-800"} hover:bg-blue-700`}
          >
            Settings
          </Button>
          <Button
            onClick={() => setActiveTab("bulk")}
            className={`${activeTab === "bulk" ? "bg-blue-600" : "bg-blue-800"} hover:bg-blue-700`}
          >
            Bulk Operations
          </Button>
        </div>

        {/* Draw Control Tab */}
        {activeTab === "control" && (
          <div className="space-y-6">
            {/* Auto Draw Control */}
            <Card className="bg-blue-800/30 border-blue-600">
              <CardHeader>
                <CardTitle>🎲 Lottery Draw Control</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Auto Draw Toggle */}
                  <div className="flex items-center justify-between p-4 bg-blue-900/50 rounded border border-blue-600">
                    <div>
                      <h3 className="text-lg font-semibold">Automatic Draws</h3>
                      <p className="text-sm text-blue-300">
                        {autoDrawEnabled
                          ? "Draws occur every 10 minutes automatically"
                          : "Automatic draws are disabled"}
                      </p>
                    </div>
                    <Button
                      onClick={toggleAutoDraw}
                      className={`px-6 py-3 text-lg font-semibold ${
                        autoDrawEnabled ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"
                      }`}
                    >
                      {autoDrawEnabled ? "🛑 Stop Auto Draw" : "▶️ Start Auto Draw"}
                    </Button>
                  </div>

                  {/* Manual Draw */}
                  <div className="flex items-center justify-between p-4 bg-blue-900/50 rounded border border-blue-600">
                    <div>
                      <h3 className="text-lg font-semibold">Manual Draw</h3>
                      <p className="text-sm text-blue-300">Generate a lottery result immediately</p>
                    </div>
                    <Button
                      onClick={handleManualDraw}
                      className="px-6 py-3 text-lg font-semibold bg-purple-600 hover:bg-purple-700"
                    >
                      🎯 Draw Now
                    </Button>
                  </div>

                  {/* Status Display */}
                  <div className="p-4 bg-blue-900/50 rounded border border-blue-600">
                    <h3 className="text-lg font-semibold mb-2">Current Status</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-400">{results.length}</div>
                        <div className="text-sm text-blue-300">Total Results</div>
                      </div>
                      <div className="text-center">
                        <div className={`text-2xl font-bold ${autoDrawEnabled ? "text-green-400" : "text-red-400"}`}>
                          {autoDrawEnabled ? "ACTIVE" : "PAUSED"}
                        </div>
                        <div className="text-sm text-blue-300">Auto Draw Status</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-400">10 MIN</div>
                        <div className="text-sm text-blue-300">Draw Interval</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-yellow-400">{settings.numbersPerDraw}</div>
                        <div className="text-sm text-blue-300">Numbers per Draw</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Results Management Tab */}
        {activeTab === "results" && (
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="bg-blue-800/30 border-blue-600">
              <CardHeader>
                <CardTitle>⚡ Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button
                    onClick={() => setNewResult({ ...newResult, numbers: generateRandomNumbers() })}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    🔄 Generate {settings.numbersPerDraw} Numbers
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Add New Result */}
            <Card className="bg-blue-800/30 border-blue-600">
              <CardHeader>
                <CardTitle>➕ Add New Result</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={newResult.date}
                      onChange={(e) => setNewResult({ ...newResult, date: e.target.value })}
                      className="bg-white text-black"
                    />
                  </div>
                  <div>
                    <Label htmlFor="time">Time</Label>
                    <Input
                      id="time"
                      type="text"
                      value={newResult.time}
                      onChange={(e) => setNewResult({ ...newResult, time: e.target.value })}
                      className="bg-white text-black"
                      placeholder="e.g., 02:00 PM"
                    />
                  </div>
                  <div>
                    <Label htmlFor="numbers">Winning Numbers ({settings.numbersPerDraw} numbers)</Label>
                    <Input
                      id="numbers"
                      type="text"
                      value={newResult.numbers}
                      onChange={(e) => setNewResult({ ...newResult, numbers: e.target.value })}
                      className="bg-white text-black"
                      placeholder={`e.g., ${Array.from({ length: settings.numbersPerDraw }, (_, i) => 1000 + i).join(", ")}`}
                    />
                  </div>
                  <div className="flex items-end">
                    <Button onClick={handleAddResult} className="w-full bg-green-600 hover:bg-green-700">
                      Add Result
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Results List */}
            <Card className="bg-blue-800/30 border-blue-600">
              <CardHeader>
                <CardTitle>📋 Current Results ({results.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {results.map((result) => (
                    <div key={result.id} className="bg-blue-900/50 p-4 rounded border border-blue-600">
                      {editingResult?.id === result.id ? (
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
                          <Input
                            value={editingResult.date}
                            onChange={(e) => setEditingResult({ ...editingResult, date: e.target.value })}
                            className="bg-white text-black text-sm"
                          />
                          <Input
                            value={editingResult.time}
                            onChange={(e) => setEditingResult({ ...editingResult, time: e.target.value })}
                            className="bg-white text-black text-sm"
                          />
                          <Input
                            value={editingResult.numbers}
                            onChange={(e) => setEditingResult({ ...editingResult, numbers: e.target.value })}
                            className="bg-white text-black text-sm"
                          />
                          <div className="flex gap-1">
                            <Button
                              onClick={handleUpdateResult}
                              className="bg-green-600 hover:bg-green-700 text-xs px-2 py-1"
                            >
                              Save
                            </Button>
                            <Button
                              onClick={() => setEditingResult(null)}
                              className="bg-gray-600 hover:bg-gray-700 text-xs px-2 py-1"
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex justify-between items-center">
                          <div className="flex-1">
                            <div className="text-sm text-blue-300">{result.date}</div>
                            <div className="font-semibold">{result.time}</div>
                            <div className="font-mono text-sm">{result.numbers}</div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              onClick={() => setEditingResult(result)}
                              className="bg-yellow-600 hover:bg-yellow-700 text-xs px-2 py-1"
                            >
                              Edit
                            </Button>
                            <Button
                              onClick={() => handleDeleteResult(result.id)}
                              className="bg-red-600 hover:bg-red-700 text-xs px-2 py-1"
                            >
                              Delete
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <div className="space-y-6">
            <Card className="bg-blue-800/30 border-blue-600">
              <CardHeader>
                <CardTitle>⚙️ Lottery Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="drawInterval">Draw Interval (minutes)</Label>
                    <Input
                      id="drawInterval"
                      type="number"
                      value={settings.drawInterval || 10}
                      onChange={(e) => {
                        const value = Number.parseInt(e.target.value) || 10
                        setSettings({ ...settings, drawInterval: value })
                      }}
                      className="bg-white text-black"
                      min="1"
                      max="60"
                    />
                  </div>
                  <div>
                    <Label htmlFor="numbersPerDraw">Numbers per Draw</Label>
                    <Input
                      id="numbersPerDraw"
                      type="number"
                      value={settings.numbersPerDraw || 5}
                      onChange={(e) => {
                        const value = Number.parseInt(e.target.value) || 5
                        setSettings({ ...settings, numbersPerDraw: value })
                      }}
                      className="bg-white text-black"
                      min="1"
                      max="20"
                    />
                  </div>
                  <div>
                    <Label htmlFor="minNumber">Minimum Number</Label>
                    <Input
                      id="minNumber"
                      type="number"
                      value={settings.minNumber || 1000}
                      onChange={(e) => {
                        const value = Number.parseInt(e.target.value) || 1000
                        setSettings({ ...settings, minNumber: value })
                      }}
                      className="bg-white text-black"
                      min="1"
                      max="9999"
                    />
                  </div>
                  <div>
                    <Label htmlFor="maxNumber">Maximum Number</Label>
                    <Input
                      id="maxNumber"
                      type="number"
                      value={settings.maxNumber || 9999}
                      onChange={(e) => {
                        const value = Number.parseInt(e.target.value) || 9999
                        setSettings({ ...settings, maxNumber: value })
                      }}
                      className="bg-white text-black"
                      min="1000"
                      max="99999"
                    />
                  </div>
                </div>
                <div className="mt-6 p-4 bg-blue-900/50 rounded border border-blue-600">
                  <h3 className="text-lg font-semibold mb-2">Current Settings Preview</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-blue-300">Numbers per Draw:</span>
                      <div className="font-bold text-yellow-400">{settings.numbersPerDraw}</div>
                    </div>
                    <div>
                      <span className="text-blue-300">Number Range:</span>
                      <div className="font-bold text-green-400">
                        {settings.minNumber} - {settings.maxNumber}
                      </div>
                    </div>
                    <div>
                      <span className="text-blue-300">Draw Interval:</span>
                      <div className="font-bold text-blue-400">{settings.drawInterval} minutes</div>
                    </div>
                    <div>
                      <span className="text-blue-300">Example Result:</span>
                      <div className="font-mono text-xs text-white">{generateRandomNumbers()}</div>
                    </div>
                  </div>
                </div>
                <div className="mt-4">
                  <Button onClick={saveSettings} className="bg-green-600 hover:bg-green-700">
                    💾 Save Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Bulk Operations Tab */}
        {activeTab === "bulk" && (
          <div className="space-y-6">
            <Card className="bg-blue-800/30 border-blue-600">
              <CardHeader>
                <CardTitle>📦 Bulk Import Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="bulkResults">Bulk Results (Format: Time|Numbers, one per line)</Label>
                    <Textarea
                      id="bulkResults"
                      value={bulkResults}
                      onChange={(e) => setBulkResults(e.target.value)}
                      className="bg-white text-black h-32"
                      placeholder={`02:00 PM|${Array.from({ length: settings.numbersPerDraw }, (_, i) => 6001 + i).join(", ")}
02:20 PM|${Array.from({ length: settings.numbersPerDraw }, (_, i) => 6011 + i).join(", ")}`}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleBulkImport} className="bg-green-600 hover:bg-green-700">
                      Import Results
                    </Button>
                    <Button onClick={() => setBulkResults("")} className="bg-gray-600 hover:bg-gray-700">
                      Clear
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-800/30 border-blue-600">
              <CardHeader>
                <CardTitle>🗑️ Bulk Operations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button
                    onClick={() => {
                      if (confirm("Are you sure you want to clear all results?")) {
                        clearAllResults()
                        alert("All results cleared!")
                      }
                    }}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    Clear All Results
                  </Button>
                  <Button
                    onClick={() => {
                      const data = results.map((r) => `${r.date},${r.time},${r.numbers}`).join("\n")
                      const blob = new Blob([data], { type: "text/csv" })
                      const url = URL.createObjectURL(blob)
                      const a = document.createElement("a")
                      a.href = url
                      a.download = "lottery_results.csv"
                      a.click()
                    }}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Export Results (CSV)
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
