"use client"

import { useEffect } from "react"

interface LiveDrawNotificationProps {
  show: boolean
  onClose: () => void
}

export function LiveDrawNotification({ show, onClose }: LiveDrawNotificationProps) {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onClose()
      }, 5000) // Auto close after 5 seconds

      return () => clearTimeout(timer)
    }
  }, [show, onClose])

  if (!show) return null

  return (
    <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-right duration-500">
      <div className="bg-green-600 text-white p-4 rounded-lg shadow-lg border border-green-400">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 bg-green-300 rounded-full animate-pulse"></div>
          <div>
            <div className="font-semibold">🎯 New Draw Result!</div>
            <div className="text-sm text-green-100">Latest lottery numbers have been drawn</div>
          </div>
          <button onClick={onClose} className="ml-4 text-green-200 hover:text-white transition-colors">
            ✕
          </button>
        </div>
      </div>
    </div>
  )
}
