"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ResultsPage } from "@/components/results-page"
import { AdminPanel } from "@/components/admin-panel"
import { usePersistentResults } from "@/hooks/use-persistent-results"

interface LotteryResult {
  time: string
  numbers: string
}

interface ResultsPageProps {
  onClose: () => void
}

export default function LotteryWebsite() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [nextDrawTime, setNextDrawTime] = useState("")
  const [isNewResult, setIsNewResult] = useState(false)
  const { results, isLoaded, addResult } = usePersistentResults()
  const [showResultsPage, setShowResultsPage] = useState(false)
  const [showAdminPanel, setShowAdminPanel] = useState(false)

  // Get auto draw status from localStorage
  const getAutoDrawStatus = () => {
    try {
      const status = localStorage.getItem("auto_draw_enabled")
      return status === "true"
    } catch {
      return false
    }
  }

  // Get lottery settings from localStorage
  const getLotterySettings = () => {
    try {
      const settings = localStorage.getItem("lottery_settings")
      return settings
        ? JSON.parse(settings)
        : {
            numbersPerDraw: 5,
            minNumber: 1000,
            maxNumber: 9999,
          }
    } catch {
      return {
        numbersPerDraw: 5,
        minNumber: 1000,
        maxNumber: 9999,
      }
    }
  }

  const [autoDrawEnabled, setAutoDrawEnabled] = useState(getAutoDrawStatus())
  const [lotterySettings, setLotterySettings] = useState(getLotterySettings())

  // Generate random lottery numbers based on settings
  const generateLotteryNumbers = () => {
    const numbers = []
    for (let i = 0; i < lotterySettings.numbersPerDraw; i++) {
      numbers.push(
        Math.floor(Math.random() * (lotterySettings.maxNumber - lotterySettings.minNumber + 1)) +
          lotterySettings.minNumber,
      )
    }
    return numbers.join(", ")
  }

  // Calculate next draw time (every 10 minutes) with proper countdown
  const calculateNextDrawTime = () => {
    const now = new Date()
    const minutes = now.getMinutes()
    const seconds = now.getSeconds()

    // Find the next 10-minute mark (0, 10, 20, 30, 40, 50)
    const nextDrawMinutes = Math.ceil(minutes / 10) * 10
    const nextDraw = new Date(now)

    if (nextDrawMinutes >= 60) {
      nextDraw.setHours(nextDraw.getHours() + 1)
      nextDraw.setMinutes(0)
    } else {
      nextDraw.setMinutes(nextDrawMinutes)
    }

    nextDraw.setSeconds(0)
    nextDraw.setMilliseconds(0)

    // Calculate time difference
    const timeDiff = nextDraw.getTime() - now.getTime()

    if (timeDiff <= 0) {
      return "00:00"
    }

    const minutesLeft = Math.floor(timeDiff / 60000)
    const secondsLeft = Math.floor((timeDiff % 60000) / 1000)

    return `${minutesLeft.toString().padStart(2, "0")}:${secondsLeft.toString().padStart(2, "0")}`
  }

  // Format current date
  const formatDate = (date: Date) => {
    return date
      .toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      })
      .replace(/\//g, "/")
  }

  // Format current time
  const formatTime = (date: Date) => {
    return date
      .toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      })
      .toLowerCase()
  }

  // Add new result (only called by admin controls now)
  const addNewResult = () => {
    const now = new Date()
    const timeString = now.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    })

    addResult({
      time: timeString,
      numbers: generateLotteryNumbers(),
      date: now.toISOString().split("T")[0],
    })

    // Show new result animation
    setIsNewResult(true)
    setTimeout(() => setIsNewResult(false), 3000)
  }

  // Listen for auto draw status changes from admin panel
  useEffect(() => {
    const handleStorageChange = () => {
      setAutoDrawEnabled(getAutoDrawStatus())
      setLotterySettings(getLotterySettings())
    }

    window.addEventListener("storage", handleStorageChange)

    // Also check periodically in case of same-tab changes
    const interval = setInterval(handleStorageChange, 1000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      clearInterval(interval)
    }
  }, [])

  // Listen for manual draw trigger from admin panel
  useEffect(() => {
    const handleManualDraw = () => {
      addNewResult()
    }

    window.addEventListener("manual_draw_trigger", handleManualDraw)
    return () => window.removeEventListener("manual_draw_trigger", handleManualDraw)
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
      setNextDrawTime(calculateNextDrawTime())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    if (!autoDrawEnabled) return

    const now = new Date()
    const minutes = now.getMinutes()
    const seconds = now.getSeconds()

    // Check if it's time for a new draw (every 10 minutes at :00 seconds)
    if (minutes % 10 === 0 && seconds === 0) {
      addNewResult()
    }
  }, [currentTime, autoDrawEnabled])

  useEffect(() => {
    setNextDrawTime(calculateNextDrawTime())
  }, [])

  // Auto-draw every 10 minutes when enabled by admin
  useEffect(() => {
    if (!autoDrawEnabled) return

    const autoDrawInterval = setInterval(() => {
      addNewResult()
    }, 600000) // 10 minutes = 600000ms

    return () => clearInterval(autoDrawInterval)
  }, [autoDrawEnabled])

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 text-white p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-xl">
            <span className="text-red-500">Result of Date : </span>
            <span className="text-red-400">{formatDate(currentTime)}</span>
          </h1>
          <div className="flex gap-2">
            <Button
              onClick={() => setShowResultsPage(true)}
              className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded"
            >
              Open Back Result
            </Button>
            <Button
              onClick={() => setShowAdminPanel(true)}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded"
            >
              Admin Panel
            </Button>
          </div>
        </div>

        {/* Results Table */}
        <div className="border border-blue-400 rounded-lg overflow-hidden mb-8">
          <div className="grid grid-cols-2 bg-blue-800/50">
            <div className="p-4 text-center font-semibold border-r border-blue-400">Draw Time</div>
            <div className="p-4 text-center font-semibold">Winning Number</div>
          </div>

          {isLoaded &&
            results.slice(0, 5).map((result, index) => (
              <div
                key={result.id}
                className={`grid grid-cols-2 border-t border-blue-400 hover:bg-blue-800/20 transition-all duration-500 ${
                  index === 0 && isNewResult ? "bg-green-600/30 animate-pulse border-green-400" : ""
                }`}
              >
                <div className="p-4 text-center border-r border-blue-400 font-semibold">
                  {index === 0 && isNewResult && <span className="inline-block mr-2 text-green-400">🆕</span>}
                  {result.time}
                </div>
                <div className="p-4 text-center font-mono text-sm md:text-base text-yellow-400">{result.numbers}</div>
              </div>
            ))}

          {!isLoaded && (
            <div className="p-8 text-center">
              <div className="text-lg">Loading results...</div>
            </div>
          )}

          {isLoaded && results.length === 0 && (
            <div className="p-8 text-center">
              <div className="text-lg text-blue-300">No results available</div>
              <div className="text-sm text-blue-400 mt-2">Check back later for lottery results</div>
            </div>
          )}
        </div>

        {/* Current Time and Next Draw */}
        <div className="text-center space-y-4">
          <div className="text-lg">{formatTime(currentTime)} IST</div>

          {/* Next Draw Countdown */}
          <div className="bg-blue-800/30 p-6 rounded-lg border border-blue-600 max-w-md mx-auto">
            <div className="text-lg mb-2">
              <span className="text-white">NEXT DRAW IN: </span>
            </div>
            <div className="text-4xl font-bold text-orange-400 font-mono tracking-wider">{nextDrawTime}</div>
            <div className="text-sm text-blue-300 mt-2">
              {nextDrawTime === "00:00" ? "Draw starting now!" : "Minutes : Seconds"}
            </div>
          </div>
        </div>

        {/* Live Update Indicator - Only show when auto draw is enabled */}
        {autoDrawEnabled && (
          <div className="text-center mt-4">
            <div className="inline-flex items-center gap-2 bg-green-600/20 px-4 py-2 rounded-full border border-green-600">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-green-300">Live Updates Active</span>
            </div>
          </div>
        )}

        {/* Lottery Info */}
        <div className="text-center mt-6">
          <div className="inline-flex items-center gap-4 text-sm text-blue-300">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
              <span>{lotterySettings.numbersPerDraw} numbers per draw</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
              <span>
                Range: {lotterySettings.minNumber} - {lotterySettings.maxNumber}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>Every 10 minutes</span>
            </div>
          </div>
        </div>

        {/* Additional Results History */}
        <div className="mt-12">
          <h2 className="text-xl mb-4 text-center">All Recent Results ({results.length})</h2>
          {isLoaded && results.length > 5 && (
            <div className="grid gap-2 max-h-96 overflow-y-auto">
              {results.slice(5).map((result) => (
                <div
                  key={result.id}
                  className="bg-blue-800/30 p-3 rounded border border-blue-600 hover:bg-blue-800/50 transition-colors"
                >
                  <div className="flex justify-between items-center">
                    <div className="flex flex-col">
                      <span className="text-blue-300 text-sm">{result.date}</span>
                      <span className="text-white font-semibold">{result.time}</span>
                    </div>
                    <span className="font-mono text-sm text-yellow-400">{result.numbers}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
          {isLoaded && results.length <= 5 && (
            <div className="text-center text-blue-300">
              <p>All results are shown in the main table above</p>
            </div>
          )}
          {!isLoaded && (
            <div className="text-center py-4">
              <div className="text-blue-300">Loading additional results...</div>
            </div>
          )}
        </div>
        {showResultsPage && <ResultsPage onClose={() => setShowResultsPage(false)} />}
        {showAdminPanel && <AdminPanel onClose={() => setShowAdminPanel(false)} />}
      </div>
    </div>
  )
}
