"use client"

import { useState, useEffect } from "react"

interface LotteryResult {
  id: string
  time: string
  numbers: string
  date: string
}

const STORAGE_KEY = "lottery_results"

export function usePersistentResults() {
  const [results, setResults] = useState<LotteryResult[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  // Load results from localStorage on mount
  useEffect(() => {
    try {
      const savedResults = localStorage.getItem(STORAGE_KEY)
      if (savedResults) {
        const parsedResults = JSON.parse(savedResults)
        setResults(parsedResults)
      } else {
        // Set default results if none exist (now with 5 numbers)
        const defaultResults: LotteryResult[] = [
          {
            id: "default_1",
            time: "01:20 PM",
            numbers: "6062, 6190, 6264, 6328, 6493",
            date: new Date().toISOString().split("T")[0],
          },
        ]
        setResults(defaultResults)
        localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultResults))
      }
    } catch (error) {
      console.error("Error loading results from localStorage:", error)
      // Fallback to default results
      const defaultResults: LotteryResult[] = [
        {
          id: "default_1",
          time: "01:20 PM",
          numbers: "6062, 6190, 6264, 6328, 6493",
          date: new Date().toISOString().split("T")[0],
        },
      ]
      setResults(defaultResults)
    }
    setIsLoaded(true)
  }, [])

  // Listen for storage changes from other tabs/windows
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY && e.newValue) {
        try {
          const newResults = JSON.parse(e.newValue)
          setResults(newResults)
        } catch (error) {
          console.error("Error parsing storage change:", error)
        }
      }
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  // Save results to localStorage whenever results change
  const updateResults = (newResults: LotteryResult[]) => {
    setResults(newResults)
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newResults))
      // Dispatch custom event for same-tab updates
      window.dispatchEvent(new CustomEvent("results_updated", { detail: newResults }))
    } catch (error) {
      console.error("Error saving results to localStorage:", error)
    }
  }

  // Add a new result
  const addResult = (result: Omit<LotteryResult, "id">) => {
    const newResult: LotteryResult = {
      ...result,
      id: Date.now().toString(),
    }
    const updatedResults = [newResult, ...results]
    updateResults(updatedResults)
    return newResult
  }

  // Update an existing result
  const updateResult = (updatedResult: LotteryResult) => {
    const updatedResults = results.map((r) => (r.id === updatedResult.id ? updatedResult : r))
    updateResults(updatedResults)
  }

  // Delete a result
  const deleteResult = (id: string) => {
    const updatedResults = results.filter((r) => r.id !== id)
    updateResults(updatedResults)
  }

  // Clear all results
  const clearAllResults = () => {
    updateResults([])
  }

  // Add multiple results (bulk import)
  const addMultipleResults = (newResults: Omit<LotteryResult, "id">[]) => {
    const resultsWithIds: LotteryResult[] = newResults.map((result, index) => ({
      ...result,
      id: `bulk_${Date.now()}_${index}`,
    }))
    const updatedResults = [...resultsWithIds, ...results]
    updateResults(updatedResults)
    return resultsWithIds
  }

  return {
    results,
    isLoaded,
    addResult,
    updateResult,
    deleteResult,
    clearAllResults,
    addMultipleResults,
    updateResults,
  }
}
