<?php
/**
 * Merchant Wallet SDK
 * Software Development Kit for handling Merchant ID + Wallet integration
 * 
 * @version 1.0.0
 * @author Digital Wallet Team
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../classes/Merchant.php';
require_once __DIR__ . '/../classes/Wallet.php';
require_once __DIR__ . '/../classes/Transaction.php';

class MerchantWalletSDK {
    private $db;
    private $merchant;
    private $wallet;
    private $transaction;
    private $api_key;
    private $merchant_id;
    
    public function __construct($api_key = null, $merchant_id = null) {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->merchant = new Merchant($this->db);
        $this->wallet = new Wallet($this->db);
        $this->transaction = new Transaction($this->db);
        $this->api_key = $api_key;
        $this->merchant_id = $merchant_id;
    }
    
    /**
     * Initialize SDK with merchant credentials
     */
    public function initialize($merchant_id, $api_key = null) {
        $this->merchant_id = $merchant_id;
        $this->api_key = $api_key;
        
        // Validate merchant exists and is active
        $merchant_data = $this->merchant->getMerchantByMerchantId($merchant_id);
        if (!$merchant_data || !is_array($merchant_data)) {
            throw new Exception("Invalid merchant ID: {$merchant_id}");
        }
        
        return $this;
    }
    
    /**
     * Get merchant information
     */
    public function getMerchantInfo() {
        if (!$this->merchant_id) {
            throw new Exception("SDK not initialized. Call initialize() first.");
        }
        
        $merchant_data = $this->merchant->getMerchantByMerchantId($this->merchant_id);
        if (!$merchant_data || !is_array($merchant_data)) {
            throw new Exception("Merchant not found");
        }
        
        return [
            'merchant_id' => $merchant_data['merchant_id'] ?? '',
            'business_name' => $merchant_data['business_name'] ?? '',
            'business_type' => $merchant_data['business_type'] ?? '',
            'wallet_id' => $merchant_data['wallet_id'] ?? '',
            'currency' => $this->getMerchantWalletCurrency(),
            'is_verified' => (bool)($merchant_data['is_verified'] ?? false),
            'is_active' => (bool)($merchant_data['is_active'] ?? false)
        ];
    }
    
    /**
     * Get merchant wallet balance
     */
    public function getWalletBalance() {
        $merchant_info = $this->getMerchantInfo();
        
        if ($this->wallet->getWalletByWalletId($merchant_info['wallet_id'])) {
            return [
                'wallet_id' => $merchant_info['wallet_id'],
                'balance' => (float)$this->wallet->balance,
                'currency' => $this->wallet->currency
            ];
        }
        
        throw new Exception("Merchant wallet not found");
    }
    
    /**
     * Process payment from customer to merchant
     */
    public function processPayment($customer_wallet_id, $amount, $order_reference = null, $customer_note = null) {
        try {
            $merchant_info = $this->getMerchantInfo();
            
            // Validate merchant is verified
            if (!$merchant_info['is_verified']) {
                throw new Exception("Merchant must be verified to process payments");
            }
            
            // Validate amount
            if ($amount <= 0) {
                throw new Exception("Amount must be greater than 0");
            }
            
            // Get merchant wallet internal ID
            if (!$this->wallet->getWalletByWalletId($merchant_info['wallet_id'])) {
                throw new Exception("Merchant wallet not found");
            }
            $merchant_wallet_internal_id = $this->wallet->id;
            
            // Validate customer wallet and get internal ID
            $customer_wallet_internal_id = null;
            if (preg_match('/^[A-Z]{3}\d{6}$/', $customer_wallet_id)) {
                // New format wallet ID
                $customer_wallet = new Wallet($this->db);
                if (!$customer_wallet->getWalletByWalletId($customer_wallet_id)) {
                    throw new Exception("Customer wallet not found");
                }
                $customer_wallet_internal_id = $customer_wallet->id;
            } else {
                // Old format numeric ID
                $customer_wallet = new Wallet($this->db);
                if (!$customer_wallet->getWalletById($customer_wallet_id)) {
                    throw new Exception("Customer wallet not found");
                }
                $customer_wallet_internal_id = $customer_wallet_id;
            }
            
            // Check currency compatibility
            if ($customer_wallet->currency !== $this->wallet->currency) {
                throw new Exception("Currency mismatch: Customer wallet ({$customer_wallet->currency}) and merchant wallet ({$this->wallet->currency}) must have same currency");
            }
            
            // Process the transfer
            $result = $this->transaction->transfer(
                $customer_wallet_internal_id,
                $merchant_wallet_internal_id,
                $amount,
                "Payment to merchant {$this->merchant_id}" . ($order_reference ? " - Order: {$order_reference}" : "")
            );
            
            if ($result) {
                // Log merchant transaction
                $this->logMerchantTransaction(
                    $customer_wallet_id,
                    $amount,
                    $this->wallet->currency,
                    'wallet_transfer',
                    $order_reference,
                    $customer_note
                );
                
                return [
                    'success' => true,
                    'transaction_id' => $this->transaction->id,
                    'merchant_id' => $this->merchant_id,
                    'amount' => $amount,
                    'currency' => $this->wallet->currency,
                    'order_reference' => $order_reference,
                    'timestamp' => date('Y-m-d H:i:s')
                ];
            }
            
            throw new Exception("Payment processing failed");
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'timestamp' => date('Y-m-d H:i:s')
            ];
        }
    }
    
    /**
     * Generate payment QR code for merchant
     */
    public function generatePaymentQR($amount, $order_reference = null, $description = null) {
        $merchant_info = $this->getMerchantInfo();
        
        $qr_data = [
            'type' => 'merchant_payment',
            'merchant_id' => $this->merchant_id,
            'wallet_id' => $merchant_info['wallet_id'],
            'amount' => $amount,
            'currency' => $merchant_info['currency'],
            'order_reference' => $order_reference,
            'description' => $description,
            'timestamp' => time()
        ];
        
        return [
            'qr_data' => json_encode($qr_data),
            'qr_string' => base64_encode(json_encode($qr_data)),
            'merchant_id' => $this->merchant_id,
            'amount' => $amount,
            'currency' => $merchant_info['currency']
        ];
    }
    
    /**
     * Validate wallet ID format
     */
    public function validateWalletId($wallet_id) {
        // Check new format (USD000001, EUR000001)
        if (preg_match('/^(USD|EUR)\d{6}$/', $wallet_id)) {
            return [
                'valid' => true,
                'format' => 'new',
                'currency' => substr($wallet_id, 0, 3),
                'number' => substr($wallet_id, 3)
            ];
        }
        
        // Check old format (numeric)
        if (is_numeric($wallet_id) && $wallet_id > 0) {
            return [
                'valid' => true,
                'format' => 'legacy',
                'currency' => null,
                'number' => $wallet_id
            ];
        }
        
        return [
            'valid' => false,
            'format' => 'invalid',
            'currency' => null,
            'number' => null
        ];
    }
    
    /**
     * Get merchant transaction history
     */
    public function getTransactionHistory($limit = 50, $offset = 0) {
        $query = "SELECT mt.*, t.status, t.created_at, t.reference_number 
                  FROM merchant_transactions mt
                  JOIN transactions t ON mt.transaction_id = t.id
                  WHERE mt.merchant_id = :merchant_id
                  ORDER BY t.created_at DESC
                  LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':merchant_id', $this->merchant_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get merchant statistics
     */
    public function getStatistics($days = 30) {
        $start_date = date('Y-m-d', strtotime("-{$days} days"));
        
        $query = "SELECT 
                    COUNT(*) as total_transactions,
                    SUM(mt.amount) as total_revenue,
                    AVG(mt.amount) as average_transaction,
                    mt.currency
                  FROM merchant_transactions mt
                  JOIN transactions t ON mt.transaction_id = t.id
                  WHERE mt.merchant_id = :merchant_id 
                    AND t.status = 'completed'
                    AND DATE(t.created_at) >= :start_date
                  GROUP BY mt.currency";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':merchant_id', $this->merchant_id);
        $stmt->bindParam(':start_date', $start_date);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Private helper methods
     */
    private function getMerchantWalletCurrency() {
        $merchant_data = $this->merchant->getMerchantByMerchantId($this->merchant_id);
        if ($merchant_data && is_array($merchant_data) && isset($merchant_data['wallet_id'])) {
            if ($this->wallet->getWalletByWalletId($merchant_data['wallet_id'])) {
                return $this->wallet->currency;
            }
        }
        return 'USD'; // Default currency
    }
    
    private function logMerchantTransaction($customer_wallet_id, $amount, $currency, $payment_method, $order_reference, $customer_note) {
        $query = "INSERT INTO merchant_transactions 
                  (merchant_id, transaction_id, customer_wallet_id, amount, currency, payment_method, order_reference, customer_note)
                  VALUES (:merchant_id, :transaction_id, :customer_wallet_id, :amount, :currency, :payment_method, :order_reference, :customer_note)";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':merchant_id', $this->merchant_id);
        $stmt->bindParam(':transaction_id', $this->transaction->id);
        $stmt->bindParam(':customer_wallet_id', $customer_wallet_id);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':currency', $currency);
        $stmt->bindParam(':payment_method', $payment_method);
        $stmt->bindParam(':order_reference', $order_reference);
        $stmt->bindParam(':customer_note', $customer_note);
        
        return $stmt->execute();
    }
}
?>
