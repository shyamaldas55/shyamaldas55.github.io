<?php
/**
 * Merchant Wallet SDK - Basic Usage Examples
 * 
 * This file demonstrates how to use the MerchantWalletSDK for common operations
 */

require_once __DIR__ . '/../MerchantWalletSDK.php';

try {
    // Find a verified merchant to use for examples
    require_once __DIR__ . '/../../config/database.php';
    require_once __DIR__ . '/../../classes/Merchant.php';
    
    $database = new Database();
    $db = $database->getConnection();
    $merchant = new Merchant($db);
    
    // Get verified merchants
    $all_merchants = $merchant->getAllMerchants();
    $verified_merchant = null;
    
    foreach ($all_merchants as $merch) {
        if ($merch['is_verified'] && $merch['is_active']) {
            $verified_merchant = $merch;
            break;
        }
    }
    
    if (!$verified_merchant) {
        echo "No verified merchants found. Please verify a merchant account first.\n";
        exit;
    }
    
    echo "Using verified merchant: {$verified_merchant['merchant_id']} - {$verified_merchant['business_name']}\n\n";
    
    // Initialize SDK with verified merchant ID
    $sdk = new MerchantWalletSDK();
    $sdk->initialize($verified_merchant['merchant_id']);
    
    echo "=== Merchant Wallet SDK Examples ===\n\n";
    
    // 1. Get merchant information
    echo "1. Getting Merchant Information:\n";
    $merchant_info = $sdk->getMerchantInfo();
    print_r($merchant_info);
    echo "\n";
    
    // 2. Check wallet balance
    echo "2. Checking Wallet Balance:\n";
    $balance = $sdk->getWalletBalance();
    print_r($balance);
    echo "\n";
    
    // 3. Find available customer wallet and process payment
    echo "3. Processing Payment:\n";
    require_once __DIR__ . '/../../classes/Wallet.php';
    $wallet = new Wallet($db);
    $query = "SELECT wallet_id, wallet_name, balance FROM wallets WHERE wallet_type != 'business' AND is_active = 1 AND currency = 'USD' AND balance > 25 LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $customer_wallet = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($customer_wallet) {
        echo "Using customer wallet: {$customer_wallet['wallet_id']} (Balance: USD {$customer_wallet['balance']})\n";
        $payment_result = $sdk->processPayment(
            $customer_wallet['wallet_id'], // Customer wallet ID
            25.99,                         // Amount
            'ORDER-12345',                 // Order reference
            'Payment for services'         // Customer note
        );
        print_r($payment_result);
    } else {
        echo "No customer wallet with sufficient balance found for payment test.\n";
    }
    echo "\n";
    
    // 4. Generate payment QR code
    echo "4. Generating Payment QR Code:\n";
    $qr_data = $sdk->generatePaymentQR(
        50.00,                 // Amount
        'ORDER-67890',         // Order reference
        'Coffee and pastries'  // Description
    );
    print_r($qr_data);
    echo "\n";
    
    // 5. Validate wallet ID
    echo "5. Validating Wallet IDs:\n";
    $validation1 = $sdk->validateWalletId('USD000001');
    $validation2 = $sdk->validateWalletId('EUR000002');
    $validation3 = $sdk->validateWalletId('invalid123');
    
    echo "USD000001: ";
    print_r($validation1);
    echo "EUR000002: ";
    print_r($validation2);
    echo "invalid123: ";
    print_r($validation3);
    echo "\n";
    
    // 6. Get transaction history
    echo "6. Getting Transaction History:\n";
    $transactions = $sdk->getTransactionHistory(10, 0); // Last 10 transactions
    print_r($transactions);
    echo "\n";
    
    // 7. Get merchant statistics
    echo "7. Getting Merchant Statistics (Last 30 days):\n";
    $stats = $sdk->getStatistics(30);
    print_r($stats);
    echo "\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
