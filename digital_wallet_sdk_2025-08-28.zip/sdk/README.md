# Merchant Wallet SDK

A comprehensive Software Development Kit for integrating Merchant ID functionality with the Digital Wallet system.

## Features

- **Merchant Authentication**: Secure merchant ID validation and initialization
- **Payment Processing**: Handle customer-to-merchant transactions
- **Wallet Integration**: Full support for currency-prefixed wallet IDs (USD000001, EUR000001)
- **QR Code Generation**: Create payment QR codes for customers
- **Transaction History**: Access merchant transaction records and statistics
- **Validation Tools**: Wallet ID format validation and verification

## Installation

```php
require_once 'path/to/sdk/MerchantWalletSDK.php';
```

## Quick Start

```php
// Initialize SDK
$sdk = new MerchantWalletSDK();
$sdk->initialize('MER000001'); // Your merchant ID

// Get merchant info
$merchant_info = $sdk->getMerchantInfo();

// Check wallet balance
$balance = $sdk->getWalletBalance();

// Process payment
$result = $sdk->processPayment('USD000005', 25.99, 'ORDER-123');
```

## Core Methods

### Initialization

```php
$sdk->initialize($merchant_id, $api_key = null)
```

Initialize the SDK with your merchant ID.

### Merchant Information

```php
$sdk->getMerchantInfo()
```

Returns merchant details including business name, wallet ID, and verification status.

### Wallet Operations

```php
$sdk->getWalletBalance()
```

Get current merchant wallet balance and currency.

### Payment Processing

```php
$sdk->processPayment($customer_wallet_id, $amount, $order_reference = null, $customer_note = null)
```

Process payment from customer wallet to merchant wallet.

**Parameters:**
- `$customer_wallet_id`: Customer's wallet ID (USD000001 format or legacy numeric)
- `$amount`: Payment amount (must be > 0)
- `$order_reference`: Optional order/invoice reference
- `$customer_note`: Optional customer note

**Returns:**
```php
[
    'success' => true,
    'transaction_id' => 12345,
    'merchant_id' => 'MER000001',
    'amount' => 25.99,
    'currency' => 'USD',
    'order_reference' => 'ORDER-123',
    'timestamp' => '2025-08-28 08:25:00'
]
```

### QR Code Generation

```php
$sdk->generatePaymentQR($amount, $order_reference = null, $description = null)
```

Generate payment QR code data for customer scanning.

### Validation

```php
$sdk->validateWalletId($wallet_id)
```

Validate wallet ID format (supports both new USD000001 and legacy numeric formats).

### Transaction History

```php
$sdk->getTransactionHistory($limit = 50, $offset = 0)
```

Retrieve merchant transaction history with pagination.

### Statistics

```php
$sdk->getStatistics($days = 30)
```

Get merchant statistics including total transactions, revenue, and averages.

## Supported Wallet Formats

- **New Format**: USD000001, EUR000001 (currency-prefixed)
- **Legacy Format**: Numeric IDs (1, 2, 3, etc.)

## Currency Support

- **USD**: US Dollar
- **EUR**: Euro

## Error Handling

All methods return structured responses with success/error indicators:

```php
// Success response
['success' => true, 'data' => [...]]

// Error response
['success' => false, 'error' => 'Error message']
```

## Examples

See the `examples/` directory for:
- `basic_usage.php`: Basic SDK operations
- `payment_processing.php`: Advanced payment scenarios

## Requirements

- PHP 7.0+
- PDO MySQL extension
- Digital Wallet database schema

## Security Notes

- Only verified merchants can process payments
- Currency compatibility is enforced
- All transactions are logged for audit trail
- Wallet ownership validation prevents unauthorized access

## Support

For integration support and documentation updates, contact the Digital Wallet development team.
