<?php

/**
 * Digital Wallet Payment Gateway SDK
 * 
 * A comprehensive PHP SDK for integrating with the Digital Wallet payment gateway.
 * Supports payment creation, processing, status checking, and webhook handling.
 * 
 * @version 1.0.0
 * @author Digital Wallet Team
 */
class PaymentGatewaySDK {
    
    private $api_key;
    private $base_url;
    private $timeout;
    private $last_response;
    private $last_error;
    
    /**
     * Initialize the Payment Gateway SDK
     * 
     * @param string $api_key Your merchant API key (starts with 'mk_')
     * @param string $base_url Base URL of the payment gateway API
     * @param int $timeout Request timeout in seconds (default: 30)
     */
    public function __construct($api_key, $base_url, $timeout = 30) {
        if (empty($api_key) || !str_starts_with($api_key, 'mk_')) {
            throw new InvalidArgumentException('Invalid API key format. API key must start with "mk_"');
        }
        
        $this->api_key = $api_key;
        $this->base_url = rtrim($base_url, '/');
        $this->timeout = $timeout;
        $this->last_response = null;
        $this->last_error = null;
    }
    
    /**
     * Create a new payment
     * 
     * @param array $payment_data Payment information
     * @return array Payment response with payment_id and payment_url
     * 
     * Example:
     * $payment = $sdk->createPayment([
     *     'amount' => 100.00,
     *     'currency' => 'USD',
     *     'description' => 'Order #12345',
     *     'customer_email' => 'customer@example.com',
     *     'return_url' => 'https://yoursite.com/success',
     *     'webhook_url' => 'https://yoursite.com/webhook'
     * ]);
     */
    public function createPayment($payment_data) {
        $required_fields = ['amount', 'currency', 'customer_email'];
        
        foreach ($required_fields as $field) {
            if (!isset($payment_data[$field]) || empty($payment_data[$field])) {
                throw new InvalidArgumentException("Missing required field: $field");
            }
        }
        
        // Validate amount
        if (!is_numeric($payment_data['amount']) || $payment_data['amount'] <= 0) {
            throw new InvalidArgumentException('Amount must be a positive number');
        }
        
        // Validate currency
        if (!in_array(strtoupper($payment_data['currency']), ['USD', 'EUR'])) {
            throw new InvalidArgumentException('Currency must be USD or EUR');
        }
        
        // Validate email
        if (!filter_var($payment_data['customer_email'], FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Invalid customer email format');
        }
        
        $data = array_merge($payment_data, ['action' => 'create_payment']);
        
        return $this->makeRequest('POST', '/api/payment_gateway.php', $data);
    }
    
    /**
     * Get payment status
     * 
     * @param string $payment_id The payment ID to check
     * @return array Payment status information
     */
    public function getPaymentStatus($payment_id) {
        if (empty($payment_id)) {
            throw new InvalidArgumentException('Payment ID is required');
        }
        
        return $this->makeRequest('GET', '/api/payment_gateway.php?payment_id=' . urlencode($payment_id));
    }
    
    /**
     * Process a payment (simulate payment completion)
     * 
     * @param string $payment_id Payment ID to process
     * @param array $payment_method Payment method data (card info, etc.)
     * @return array Processing result
     */
    public function processPayment($payment_id, $payment_method = []) {
        if (empty($payment_id)) {
            throw new InvalidArgumentException('Payment ID is required');
        }
        
        $data = [
            'action' => 'process_payment',
            'payment_id' => $payment_id,
            'payment_method' => $payment_method
        ];
        
        return $this->makeRequest('POST', '/api/payment_gateway.php', $data);
    }
    
    /**
     * Get merchant wallet information
     * 
     * @return array Wallet information
     */
    public function getWalletInfo() {
        return $this->makeRequest('GET', '/api/wallet_info.php');
    }
    
    /**
     * Verify webhook signature (for webhook endpoint security)
     * 
     * @param string $payload Raw webhook payload
     * @param string $signature Webhook signature from headers
     * @param string $webhook_secret Your webhook secret
     * @return bool True if signature is valid
     */
    public function verifyWebhookSignature($payload, $signature, $webhook_secret) {
        $expected_signature = hash_hmac('sha256', $payload, $webhook_secret);
        return hash_equals($expected_signature, $signature);
    }
    
    /**
     * Handle webhook payload
     * 
     * @param string $payload Raw webhook payload
     * @return array Parsed webhook data
     */
    public function parseWebhook($payload) {
        $data = json_decode($payload, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException('Invalid JSON payload');
        }
        
        return $data;
    }
    
    /**
     * Generate a test payment for development
     * 
     * @param float $amount Payment amount
     * @param string $currency Currency code
     * @return array Test payment data
     */
    public function createTestPayment($amount = 10.00, $currency = 'USD') {
        return $this->createPayment([
            'amount' => $amount,
            'currency' => $currency,
            'description' => 'Test Payment - ' . date('Y-m-d H:i:s'),
            'customer_email' => 'test@example.com',
            'return_url' => 'https://example.com/success',
            'webhook_url' => 'https://example.com/webhook'
        ]);
    }
    
    /**
     * Get the last API response
     * 
     * @return array|null Last response data
     */
    public function getLastResponse() {
        return $this->last_response;
    }
    
    /**
     * Get the last error message
     * 
     * @return string|null Last error message
     */
    public function getLastError() {
        return $this->last_error;
    }
    
    /**
     * Make HTTP request to the API
     * 
     * @param string $method HTTP method (GET, POST)
     * @param string $endpoint API endpoint
     * @param array $data Request data
     * @return array API response
     */
    private function makeRequest($method, $endpoint, $data = null) {
        $url = $this->base_url . $endpoint;
        
        $ch = curl_init();
        
        // Basic cURL options
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false, // For development only
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-API-Key: ' . $this->api_key,
                'User-Agent: PaymentGatewaySDK/1.0'
            ]
        ]);
        
        // Method-specific options
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        }
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        
        curl_close($ch);
        
        // Handle cURL errors
        if ($curl_error) {
            $this->last_error = 'cURL Error: ' . $curl_error;
            throw new RuntimeException($this->last_error);
        }
        
        // Parse response
        $decoded_response = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->last_error = 'Invalid JSON response: ' . json_last_error_msg();
            throw new RuntimeException($this->last_error);
        }
        
        $this->last_response = $decoded_response;
        
        // Handle HTTP errors
        if ($http_code >= 400) {
            $error_message = $decoded_response['error'] ?? 'HTTP Error ' . $http_code;
            $this->last_error = $error_message;
            throw new RuntimeException($error_message);
        }
        
        // Handle API errors
        if (isset($decoded_response['success']) && !$decoded_response['success']) {
            $this->last_error = $decoded_response['error'] ?? 'Unknown API error';
            throw new RuntimeException($this->last_error);
        }
        
        return $decoded_response;
    }
    
    /**
     * Get supported currencies
     * 
     * @return array List of supported currency codes
     */
    public static function getSupportedCurrencies() {
        return ['USD', 'EUR'];
    }
    
    /**
     * Get test card numbers for development
     * 
     * @return array Test card numbers and their expected results
     */
    public static function getTestCards() {
        return [
            'success' => [
                '4111111111111111' => 'Visa - Success',
                '4242424242424242' => 'Visa - Success',
                '5555555555554444' => 'Mastercard - Success'
            ],
            'failure' => [
                '4000000000000002' => 'Card Declined',
                '4000000000000010' => 'Invalid Card Number'
            ]
        ];
    }
    
    /**
     * Format amount for display
     * 
     * @param float $amount Amount to format
     * @param string $currency Currency code
     * @return string Formatted amount
     */
    public static function formatAmount($amount, $currency = 'USD') {
        $symbols = [
            'USD' => '$',
            'EUR' => '€'
        ];
        
        $symbol = $symbols[$currency] ?? $currency . ' ';
        return $symbol . number_format($amount, 2);
    }
    
    /**
     * Validate webhook payload structure
     * 
     * @param array $payload Webhook payload
     * @return bool True if valid
     */
    public static function isValidWebhookPayload($payload) {
        $required_fields = ['event', 'payment_id', 'amount', 'currency', 'status'];
        
        foreach ($required_fields as $field) {
            if (!isset($payload[$field])) {
                return false;
            }
        }
        
        return true;
    }
}

/**
 * Payment Gateway Exception class for better error handling
 */
class PaymentGatewayException extends Exception {
    private $response_data;
    
    public function __construct($message, $code = 0, $response_data = null, Exception $previous = null) {
        parent::__construct($message, $code, $previous);
        $this->response_data = $response_data;
    }
    
    public function getResponseData() {
        return $this->response_data;
    }
}
?>
