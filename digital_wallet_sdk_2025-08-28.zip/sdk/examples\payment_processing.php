<?php
/**
 * Merchant Wallet SDK - Payment Processing Examples
 * 
 * Advanced payment processing scenarios
 */

require_once __DIR__ . '/../MerchantWalletSDK.php';

class PaymentProcessor {
    private $sdk;
    
    public function __construct($merchant_id) {
        $this->sdk = new MerchantWalletSDK();
        $this->sdk->initialize($merchant_id);
    }
    
    public function getSdk() {
        return $this->sdk;
    }
    
    /**
     * Process single payment with validation
     */
    public function processSinglePayment($customer_wallet_id, $amount, $order_id = null) {
        try {
            // Validate wallet ID format
            $wallet_validation = $this->sdk->validateWalletId($customer_wallet_id);
            if (!$wallet_validation['valid']) {
                return ['success' => false, 'error' => 'Invalid wallet ID format'];
            }
            
            // Check merchant balance before processing
            $merchant_balance = $this->sdk->getWalletBalance();
            echo "Merchant balance before payment: {$merchant_balance['currency']} {$merchant_balance['balance']}\n";
            
            // Process payment
            $result = $this->sdk->processPayment(
                $customer_wallet_id,
                $amount,
                $order_id,
                "Payment processed via SDK"
            );
            
            if ($result['success']) {
                echo "Payment successful! Transaction ID: {$result['transaction_id']}\n";
                
                // Check updated balance
                $updated_balance = $this->sdk->getWalletBalance();
                echo "Merchant balance after payment: {$updated_balance['currency']} {$updated_balance['balance']}\n";
            }
            
            return $result;
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Process batch payments
     */
    public function processBatchPayments($payments) {
        $results = [];
        $successful = 0;
        $failed = 0;
        
        foreach ($payments as $payment) {
            $result = $this->processSinglePayment(
                $payment['customer_wallet_id'],
                $payment['amount'],
                $payment['order_id'] ?? null
            );
            
            $results[] = $result;
            
            if ($result['success']) {
                $successful++;
            } else {
                $failed++;
                echo "Payment failed: {$result['error']}\n";
            }
        }
        
        return [
            'total' => count($payments),
            'successful' => $successful,
            'failed' => $failed,
            'results' => $results
        ];
    }
    
    /**
     * Generate payment link/QR for customer
     */
    public function createPaymentRequest($amount, $description, $order_id = null) {
        $qr_data = $this->sdk->generatePaymentQR($amount, $order_id, $description);
        
        // In a real implementation, you might save this to database
        // and generate a payment URL
        $payment_url = "https://yourapp.com/pay/" . base64_encode($qr_data['qr_string']);
        
        return [
            'payment_url' => $payment_url,
            'qr_data' => $qr_data['qr_data'],
            'amount' => $amount,
            'description' => $description,
            'expires_at' => date('Y-m-d H:i:s', strtotime('+1 hour'))
        ];
    }
}

// Example usage
try {
    // First, let's check if we have any merchants in the database
    require_once __DIR__ . '/../../config/database.php';
    require_once __DIR__ . '/../../classes/Merchant.php';
    
    $database = new Database();
    $db = $database->getConnection();
    $merchant = new Merchant($db);
    
    // Get all merchants to find a valid one
    $all_merchants = $merchant->getAllMerchants();
    
    if (empty($all_merchants)) {
        echo "No merchants found in database. Please create a merchant account first.\n";
        exit;
    }
    
    // Use the first verified merchant
    $test_merchant = null;
    foreach ($all_merchants as $merch) {
        if ($merch['is_verified'] && $merch['is_active']) {
            $test_merchant = $merch;
            break;
        }
    }
    
    if (!$test_merchant) {
        echo "No verified merchants found. Please verify a merchant account first.\n";
        echo "Available merchants:\n";
        foreach ($all_merchants as $merch) {
            echo "- {$merch['merchant_id']}: {$merch['business_name']} (Verified: " . ($merch['is_verified'] ? 'Yes' : 'No') . ")\n";
        }
        exit;
    }
    
    echo "Using merchant: {$test_merchant['merchant_id']} - {$test_merchant['business_name']}\n\n";
    
    $processor = new PaymentProcessor($test_merchant['merchant_id']);
    
    echo "=== Payment Processing Examples ===\n\n";
    
    // Get merchant info first
    echo "0. Getting Merchant Information:\n";
    try {
        $merchant_info = $processor->getSdk()->getMerchantInfo();
        print_r($merchant_info);
        echo "\n";
        
        // Check wallet balance
        echo "Checking Wallet Balance:\n";
        $balance = $processor->getSdk()->getWalletBalance();
        print_r($balance);
        echo "\n";
    } catch (Exception $e) {
        echo "Error getting merchant info: " . $e->getMessage() . "\n\n";
    }
    
    // Get available customer wallets
    echo "Finding available customer wallets:\n";
    require_once __DIR__ . '/../../classes/Wallet.php';
    $wallet = new Wallet($db);
    $query = "SELECT wallet_id, wallet_name, currency, balance FROM wallets WHERE wallet_type != 'business' AND is_active = 1 AND currency = 'USD' LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $customer_wallets = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($customer_wallets)) {
        echo "No customer wallets found for testing.\n";
        exit;
    }
    
    echo "Available customer wallets:\n";
    foreach ($customer_wallets as $cw) {
        echo "- {$cw['wallet_id']}: {$cw['wallet_name']} ({$cw['currency']} {$cw['balance']})\n";
    }
    echo "\n";
    
    // Use first available wallet for single payment
    $test_wallet = $customer_wallets[0]['wallet_id'];
    
    // Single payment
    echo "1. Processing Single Payment:\n";
    $single_result = $processor->processSinglePayment($test_wallet, 15.99, 'ORDER-001');
    print_r($single_result);
    echo "\n";
    
    // Batch payments - use available wallets
    echo "2. Processing Batch Payments:\n";
    $batch_payments = [];
    for ($i = 0; $i < min(3, count($customer_wallets)); $i++) {
        $batch_payments[] = [
            'customer_wallet_id' => $customer_wallets[$i]['wallet_id'],
            'amount' => 10.00 + ($i * 5),
            'order_id' => 'ORDER-' . sprintf('%03d', $i + 2)
        ];
    }
    
    $batch_result = $processor->processBatchPayments($batch_payments);
    print_r($batch_result);
    echo "\n";
    
    // Payment request
    echo "3. Creating Payment Request:\n";
    $payment_request = $processor->createPaymentRequest(
        99.99,
        "Premium subscription",
        "SUB-12345"
    );
    print_r($payment_request);
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
