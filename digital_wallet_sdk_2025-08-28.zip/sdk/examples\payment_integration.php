<?php
/**
 * Payment Gateway SDK Integration Example
 * 
 * This example demonstrates how to integrate the Digital Wallet Payment Gateway
 * into your application for processing payments.
 */

require_once __DIR__ . '/../PaymentGatewaySDK.php';

// Initialize the SDK with your API key
$api_key = 'mk_your_api_key_here'; // Replace with your actual API key
$base_url = 'https://yoursite.com/wt'; // Replace with your base URL
$sdk = new PaymentGatewaySDK($api_key, $base_url);

try {
    echo "<h2>Payment Gateway SDK Examples</h2>";
    
    // Example 1: Create a Payment
    echo "<h3>1. Creating a Payment</h3>";
    
    $payment_data = [
        'amount' => 99.99,
        'currency' => 'USD',
        'description' => 'Premium Subscription - Monthly',
        'customer_email' => 'customer@example.com',
        'return_url' => 'https://yoursite.com/success',
        'webhook_url' => 'https://yoursite.com/webhook'
    ];
    
    $payment = $sdk->createPayment($payment_data);
    
    if ($payment['success']) {
        echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<strong>Payment Created Successfully!</strong><br>";
        echo "Payment ID: " . $payment['payment_id'] . "<br>";
        echo "Amount: " . PaymentGatewaySDK::formatAmount($payment['amount'], $payment['currency']) . "<br>";
        echo "Status: " . ucfirst($payment['status']) . "<br>";
        echo "Payment URL: <a href='" . $payment['payment_url'] . "' target='_blank'>Pay Now</a><br>";
        echo "</div>";
        
        $payment_id = $payment['payment_id'];
    } else {
        echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<strong>Error:</strong> " . $payment['error'];
        echo "</div>";
    }
    
    // Example 2: Check Payment Status
    if (isset($payment_id)) {
        echo "<h3>2. Checking Payment Status</h3>";
        
        $status = $sdk->getPaymentStatus($payment_id);
        
        if ($status['success']) {
            echo "<div style='background: #d1ecf1; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<strong>Payment Status:</strong><br>";
            echo "Payment ID: " . $status['payment_id'] . "<br>";
            echo "Amount: " . PaymentGatewaySDK::formatAmount($status['amount'], $status['currency']) . "<br>";
            echo "Status: " . ucfirst($status['status']) . "<br>";
            echo "Customer: " . $status['customer_email'] . "<br>";
            echo "Created: " . $status['created_at'] . "<br>";
            echo "</div>";
        }
    }
    
    // Example 3: Process Payment (Simulate)
    if (isset($payment_id)) {
        echo "<h3>3. Processing Payment (Test)</h3>";
        
        $test_card = [
            'card_number' => '4111111111111111',
            'expiry_month' => '12',
            'expiry_year' => '25',
            'cvv' => '123',
            'cardholder_name' => 'John Doe'
        ];
        
        $result = $sdk->processPayment($payment_id, $test_card);
        
        if ($result['success']) {
            echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<strong>Payment Processed Successfully!</strong><br>";
            echo "Status: " . ucfirst($result['status']) . "<br>";
            echo "Message: " . $result['message'] . "<br>";
            echo "</div>";
        } else {
            echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<strong>Processing Failed:</strong> " . $result['error'];
            echo "</div>";
        }
    }
    
    // Example 4: Get Wallet Information
    echo "<h3>4. Merchant Wallet Information</h3>";
    
    try {
        $wallet_info = $sdk->getWalletInfo();
        
        if ($wallet_info['success']) {
            echo "<div style='background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<strong>Wallet Information:</strong><br>";
            echo "Wallet ID: " . $wallet_info['wallet_id'] . "<br>";
            echo "Balance: " . PaymentGatewaySDK::formatAmount($wallet_info['balance'], $wallet_info['currency']) . "<br>";
            echo "Currency: " . $wallet_info['currency'] . "<br>";
            echo "</div>";
        }
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<strong>Wallet Info Error:</strong> " . $e->getMessage();
        echo "</div>";
    }
    
    // Example 5: Test Payment Creation
    echo "<h3>5. Create Test Payment</h3>";
    
    $test_payment = $sdk->createTestPayment(25.00, 'USD');
    
    if ($test_payment['success']) {
        echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<strong>Test Payment Created!</strong><br>";
        echo "Payment ID: " . $test_payment['payment_id'] . "<br>";
        echo "Amount: " . PaymentGatewaySDK::formatAmount($test_payment['amount'], $test_payment['currency']) . "<br>";
        echo "Payment URL: <a href='" . $test_payment['payment_url'] . "' target='_blank'>Test Payment</a><br>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<strong>SDK Error:</strong> " . $e->getMessage() . "<br>";
    echo "<strong>Last Error:</strong> " . $sdk->getLastError() . "<br>";
    echo "</div>";
}

// Display SDK Information
echo "<h3>SDK Information</h3>";
echo "<div style='background: #e2e3e5; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
echo "<strong>Supported Currencies:</strong> " . implode(', ', PaymentGatewaySDK::getSupportedCurrencies()) . "<br><br>";

echo "<strong>Test Cards:</strong><br>";
$test_cards = PaymentGatewaySDK::getTestCards();
foreach ($test_cards['success'] as $card => $description) {
    echo "✅ " . $card . " - " . $description . "<br>";
}
foreach ($test_cards['failure'] as $card => $description) {
    echo "❌ " . $card . " - " . $description . "<br>";
}
echo "</div>";

// Webhook Example
echo "<h3>Webhook Handler Example</h3>";
echo "<pre style='background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto;'>";
echo htmlspecialchars('<?php
// webhook.php - Handle payment webhooks

require_once "PaymentGatewaySDK.php";

$payload = file_get_contents("php://input");
$signature = $_SERVER["HTTP_X_WEBHOOK_SIGNATURE"] ?? "";
$webhook_secret = "your_webhook_secret_here";

$sdk = new PaymentGatewaySDK("your_api_key", "your_base_url");

try {
    // Verify webhook signature (recommended for security)
    if (!$sdk->verifyWebhookSignature($payload, $signature, $webhook_secret)) {
        http_response_code(401);
        exit("Invalid signature");
    }
    
    // Parse webhook data
    $webhook_data = $sdk->parseWebhook($payload);
    
    // Validate payload structure
    if (!PaymentGatewaySDK::isValidWebhookPayload($webhook_data)) {
        http_response_code(400);
        exit("Invalid payload");
    }
    
    // Handle different webhook events
    switch ($webhook_data["event"]) {
        case "payment.completed":
            // Payment was successful
            $payment_id = $webhook_data["payment_id"];
            $amount = $webhook_data["amount"];
            
            // Update your database, send confirmation email, etc.
            updateOrderStatus($payment_id, "paid");
            sendConfirmationEmail($webhook_data["customer_email"]);
            break;
            
        case "payment.failed":
            // Payment failed
            $payment_id = $webhook_data["payment_id"];
            updateOrderStatus($payment_id, "failed");
            break;
    }
    
    // Return success response
    http_response_code(200);
    echo "OK";
    
} catch (Exception $e) {
    error_log("Webhook error: " . $e->getMessage());
    http_response_code(500);
    exit("Webhook processing failed");
}
?>');
echo "</pre>";
?>

<style>
body {
    font-family: Arial, sans-serif;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    line-height: 1.6;
}
h2, h3 {
    color: #333;
}
pre {
    font-size: 14px;
    line-height: 1.4;
}
a {
    color: #007bff;
    text-decoration: none;
}
a:hover {
    text-decoration: underline;
}
</style>
